<?php
// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'eblood');
	
//include("auth.php");

	$question_ID	= $_REQUEST['question_ID'];
	$query 			= "SELECT * from question where question_ID='".$question_ID."'"; 
	$result 		= mysqli_query($db, $query) or die ( mysqli_error());
	$row 			= mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Record</title>
<!-- <link rel="stylesheet" href="css/style.css" /> -->
</head>
<body>
<div class="form">
<table bgcolor=white border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="bigframe">
		  <tr>
			<td width="100%" valign=top>
			<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
			  <tr>
					<!--- Isi --->
					<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">    
					  <tr>
						<td>&nbsp;</td>
							<tr bgColor="#000000" style="font-family: sans-serif; color: white " >
						<td width="100%">&nbsp;<b>Update Record || Questionnaire</b></td>
					  </tr>
					  <tr>
						<td width="100%">&nbsp;</td>
					  </tr>
					  <tr>
						<td width="100%">
							<table width="100%" style="font-family:Arial, Helvetica, sans-serif; font-size:14px">
							<?php
							if(isset($_POST['new']) && $_POST['new']==1)
							{
							$question_ID = $_REQUEST['question_ID'];
							$questions	 = $_REQUEST['questions'];
							
							
							$update="UPDATE question set  
							questions='".$questions."'
							where question_ID='".$question_ID."'";
							
							mysqli_query($db, $update) or die(mysqli_error($db));
							
							echo ("<script LANGUAGE='Javascript'> 
							window.alert('Data have been successfully updated');
							window.location.href='question_form.php';
							</script>");
							
							}else {
							?>
								<div>
								<form name="form" method="post" action=""> 
								<input type="hidden" name="new" value="1" />
								<tr>
									<td align="right" width="15%">Question ID: </td>
									<td align="left" width="25%">
										<input type="text" name="question_ID" id="question_ID" disabled size="15" value="<?php echo $row['question_ID'];?>">	
									</td>
								</tr>
								<tr>
									<td align="right" width="15%">Question : </td>
									<td align="left" width="25%">
										<textarea name="questions" required id="questions"  rows="5" cols="50"><?php echo $row['questions'];?></textarea>
									</td>
								</tr>								
								</table>							
							<tr>
								<td align="right" width="100%" >
									<input name="submit" type="submit" value="Update" />
									<input type="button" name="backBtn" value="Back to Main Page" onClick="window.location.href='index_admin.php'">
									<input type="button" name="resetBtn" value="Reset" onClick="window.location.href=self.location"> 
								</td>
							</td>
							<?php } ?>
							</form>
							<p style="color:#FF0000;">
							<tr>
								<td>&nbsp;</td>
									<tr bgColor="#000000" style="font-family: sans-serif; color: white " >
								<td width="100%">&nbsp;
								</td>
							  </tr>

</div>
</div>
</body>
</html>
