e-Blood Management System

workshop1/login.php

--User Type: Admin--
Username: Admin
Password: 1234

--User Type: Staff--
Username: Nurse
Password: 1234

--User Type: Donor--
Username: fatin
Password: 1234